# DECISIONS

Important decisions, rationale, and tradeoffs.

## Entries

- (empty)
