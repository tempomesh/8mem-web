# CORRECTIONS

Persistent corrections made by the user.

## Entries

- (empty)
