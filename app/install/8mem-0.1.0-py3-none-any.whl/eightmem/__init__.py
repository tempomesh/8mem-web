"""8mem: local-first memory layer for AI chats."""

__all__ = ["__version__"]
__version__ = "0.1.0"
